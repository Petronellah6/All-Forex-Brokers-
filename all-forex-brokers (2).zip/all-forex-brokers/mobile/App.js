import React from 'react'
import { SafeAreaView } from 'react-native'
import { WebView } from 'react-native-webview'

export default function App() {
  const WEB_URL = 'https://your-deployed-site.vercel.app'
  return (
    <SafeAreaView style={{flex:1}}>
      <WebView source={{ uri: WEB_URL }} style={{flex:1}} />
    </SafeAreaView>
  )
}
