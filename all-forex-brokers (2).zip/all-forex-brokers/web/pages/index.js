import { useState, useMemo } from 'react'
import useSWR from 'swr'
import BrokerCard from '../components/BrokerCard'

const fetcher = (url) => fetch(url).then(r => r.json())

export default function Home() {
  const { data: brokers } = useSWR('/api/brokers', fetcher, { fallbackData: [] })
  const [q, setQ] = useState('')
  const [region, setRegion] = useState('All')

  const regions = useMemo(() => ['All', ...Array.from(new Set((brokers||[]).map(b => b.region)))], [brokers])

  const filtered = useMemo(() => (brokers||[])
    .filter(b => b.name.toLowerCase().includes(q.toLowerCase()))
    .filter(b => region === 'All' || b.region === region), [brokers, q, region])

  return (
    <div className="max-w-6xl mx-auto p-6">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">All Forex Brokers</h1>
        <a href="/admin" className="px-4 py-2 border rounded">Admin</a>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search brokers..." className="p-2 border rounded" />
        <select value={region} onChange={e => setRegion(e.target.value)} className="p-2 border rounded">
          {regions.map(r => <option key={r} value={r}>{r}</option>)}
        </select>
        <div />
      </div>

      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(b => <BrokerCard key={b.id} broker={b} />)}
      </section>
    </div>
  )
}
