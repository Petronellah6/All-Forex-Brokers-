# All Forex Brokers — Ready scaffold

This archive contains a minimal Next.js web app (`/web`) and an Expo mobile app (`/mobile`).
Follow instructions in the chat or ask me to produce a hosted GitHub repo.

- Web: `cd web && npm install && npm run dev`
- Mobile: `cd mobile && npm install && npx expo start`

Replace `web/data/brokers.json` with your full broker list or use the admin CSV importer at `/admin`.
