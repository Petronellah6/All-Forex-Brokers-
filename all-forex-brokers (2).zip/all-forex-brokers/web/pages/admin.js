import { useState } from 'react'
import Router from 'next/router'

export default function Admin() {
  const [csv, setCsv] = useState('')

  function importCSV() {
    fetch('/api/brokers', { method: 'POST', headers: {'Content-Type':'text/csv'}, body: csv })
      .then(r => r.json())
      .then(() => Router.push('/'))
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-semibold mb-3">Admin — Import Brokers CSV</h2>
      <p className="text-sm text-gray-600 mb-3">CSV format: Name,ID,Region,Regulation,MinDeposit,Features(semi-colon),AffiliateURL</p>
      <textarea rows={10} value={csv} onChange={e => setCsv(e.target.value)} className="w-full p-2 border rounded mb-3" />
      <div className="flex gap-2">
        <button onClick={importCSV} className="px-3 py-1 bg-blue-600 text-white rounded">Import</button>
      </div>
    </div>
  )
}
