import fs from 'fs'
import path from 'path'

const DATA_PATH = path.join(process.cwd(), 'data', 'brokers.json')

export default function handler(req, res) {
  if (req.method === 'GET') {
    const raw = fs.readFileSync(DATA_PATH, 'utf8')
    res.status(200).json(JSON.parse(raw))
    return
  }

  if (req.method === 'POST') {
    const csv = req.body
    try {
      const lines = (typeof csv === 'string' ? csv : '')
        .split(/\r?\n/).map(l => l.trim()).filter(Boolean)
      const parsed = lines.map(line => {
        const parts = line.split(',')
        return {
          id: (parts[1]||parts[0]).toLowerCase().replace(/\s+/g,'-'),
          name: parts[0]||'',
          region: parts[2]||'',
          regulation: parts[3]||'',
          min_deposit: parts[4]||'',
          features: (parts[5]||'').split(';').filter(Boolean),
          affiliate_url: parts[6]||''
        }
      })
      fs.writeFileSync(DATA_PATH, JSON.stringify(parsed, null, 2), 'utf8')
      res.status(200).json({ok:true})
    } catch (e) {
      res.status(500).json({error: e.message})
    }
    return
  }

  res.status(405).end()
}
