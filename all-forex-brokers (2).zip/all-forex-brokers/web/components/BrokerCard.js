export default function BrokerCard({ broker }) {
  return (
    <article className="bg-white rounded p-4 shadow">
      <div className="flex justify-between">
        <div>
          <h3 className="font-semibold">{broker.name}</h3>
          <p className="text-sm text-gray-600">{broker.region} • {broker.regulation}</p>
        </div>
        <div className="text-right">
          <p className="text-sm">Min: {broker.min_deposit}</p>
          <div className="mt-2 space-x-2">
            <a className="px-3 py-1 bg-green-600 text-white rounded inline-block" href={broker.affiliate_url} target="_blank" rel="noopener noreferrer">Sign up</a>
          </div>
        </div>
      </div>
      {broker.features?.length ? (
        <ul className="text-sm mt-3 list-disc ml-5">{broker.features.map((f,i)=><li key={i}>{f}</li>)}</ul>
      ) : null}
    </article>
  )
}
